#!/usr/bin/env bash
# Open the existing fake-hardware MoveIt demo and its saved Gaussian scene.
set -e
source /opt/ros/humble/setup.bash
source "$HOME/aubo_ws/install/setup.bash"
source "$HOME/rvizsplat_humble_ws/install/local_setup.bash"
if ! glxinfo -B >/dev/null 2>&1; then
  export LIBGL_ALWAYS_SOFTWARE=1
  export __GLX_VENDOR_LIBRARY_NAME=mesa
  printf 'GPU OpenGL initialization failed; using temporary Mesa software rendering.\n'
fi
exec ros2 launch aubo_i5_scissors_moveit_config demo.launch.py \
  rviz_config:="$HOME/aubo_ws/src/aubo_i5_scissors_moveit_config/config/moveit.rviz" "$@"
